import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, confusion_matrix, accuracy_score
import numpy as np


#CSV faylni yuklash
file_path = "supermarket_sales.csv"  
data_set = pd.read_csv(file_path)

# 'Vaqt' ustunini soat formatiga o‘tkazish
data_set['Soat'] = pd.to_datetime(data_set['Vaqt'], format='%H:%M:%S', errors='coerce').dt.hour

# Soat bo‘yicha savdolarni guruhlash va o‘rtacha qiymatni olish
savdo_soat = data_set.groupby('Soat', as_index=False)['Jami'].mean()

# Ma'lumotlarni tayyorlash
data_set = data_set.dropna()  # Bo‘sh qiymatlarni o‘chirish
data_set = pd.get_dummies(data_set, columns=['Filial', 'Mijoz_turi', 'Tolov_usuli', 'Mahsulot_turi'])

# Maqsadli ustun (savdo miqdori) va xususiyatlarni ajratish
X = data_set.drop(columns=['Jami', 'Vaqt', 'Sana'])
y = data_set['Jami']

# Model uchun ma'lumotlarni bo‘lish (train-test split)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Random Forest modelini yaratish va o‘qitish
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Bashorat qilish
y_pred = model.predict(X_test)

# Model natijalarini baholash
mae = mean_absolute_error(y_test, y_pred)
print(f"O‘rtacha absolyut xatolik (MAE): {mae}")

#  Bashoratlarni klassifikatsiya qilish (confusion matrix uchun)
threshold = np.median(y_test)  # O‘rtacha savdolarni aniqlash uchun o‘rtacha qiymatni olish
y_test_class = (y_test >= threshold).astype(int)
y_pred_class = (y_pred >= threshold).astype(int)

#  Confusion Matrix
conf_matrix = confusion_matrix(y_test_class, y_pred_class)
accuracy = accuracy_score(y_test_class, y_pred_class)

print("Confusion Matrix:")
print(conf_matrix)
print(f"Aniqlik: {accuracy:.2f}")

#  Confusion matrixni vizualizatsiya qilish
plt.figure(figsize=(5, 5))
sns.heatmap(conf_matrix, annot=True, fmt="d", cmap="Blues", xticklabels=["Past savdo", "Yuqori savdo"], yticklabels=["Past savdo", "Yuqori savdo"])
plt.xlabel("Bashorat qilingan")
plt.ylabel("Haqiqiy")
plt.title("Confusion Matrix")
plt.show()
